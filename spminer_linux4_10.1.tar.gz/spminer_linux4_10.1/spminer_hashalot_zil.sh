#!/bin/bash

WORKER=$(whoami)
USER=vtc1q2nsj2802cc3phgqrsmuxey8gtucrxajs259dcy
PASS=x
VERTHASH_DATA_FILE=verthash.dat

./spminer --zil-sleep -o stratum+tcp://vertcoin.hashalot.net:3950 -u $USER.$WORKER -p $PASS --verthash-data $VERTHASH_DATA_FILE --all-cu-devices --all-cl-devices