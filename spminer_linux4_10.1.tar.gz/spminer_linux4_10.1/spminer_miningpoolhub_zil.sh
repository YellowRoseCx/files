#!/bin/bash

WORKER=$(whoami)
USER=binaryf
PASS=x
VERTHASH_DATA_FILE=verthash.dat

./spminer --zil-sleep -o stratum+tcp://hub.miningpoolhub.com:20534 -u $USER.$WORKER -p $PASS --verthash-data $VERTHASH_DATA_FILE --all-cu-devices --all-cl-devices