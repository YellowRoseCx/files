#!/bin/bash

WORKER=$(whoami)
USER=vtc1q2nsj2802cc3phgqrsmuxey8gtucrxajs259dcy
PASS=x
VERTHASH_DATA_FILE=verthash.dat

./spminer -o stratum+tcp://p2p-spb.xyz:9171 -u $USER.$WORKER -p $PASS --verthash-data $VERTHASH_DATA_FILE --all-cu-devices --all-cl-devices